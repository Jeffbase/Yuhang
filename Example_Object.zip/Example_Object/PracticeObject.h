#ifndef PRAC_OBJ
#define PRAC_OBJ

class Prac_Obj{
public:
        int a;
        char b;
        Prac_Obj();
        Prac_Obj(int, char);
        int do_math();

};

//nonmember defs go here

#endif

